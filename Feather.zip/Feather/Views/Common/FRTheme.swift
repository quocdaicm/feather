//
//  FRTheme.swift
//  Feather
//
//  Design system: spacing, cards, buttons and icon tiles shared by the app.
//

import SwiftUI

// MARK: - Tokens
enum FRTheme {
	static let cardRadius: CGFloat = 20
	static let rowInsets = EdgeInsets(top: 5, leading: 16, bottom: 5, trailing: 16)
}

// MARK: - Card
struct FRCardModifier: ViewModifier {
	var selected: Bool = false
	var padding: CGFloat = 12
	
	func body(content: Content) -> some View {
		content
			.padding(padding)
			.background(
				RoundedRectangle(cornerRadius: FRTheme.cardRadius, style: .continuous)
					.fill(selected ? Color.accentColor.opacity(0.12) : Color(.secondarySystemGroupedBackground))
			)
			.overlay(
				RoundedRectangle(cornerRadius: FRTheme.cardRadius, style: .continuous)
					.strokeBorder(
						selected ? Color.accentColor.opacity(0.5) : Color.primary.opacity(0.06),
						lineWidth: 1
					)
			)
			.shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 3)
	}
}

extension View {
	/// Rounded elevated card surface.
	func frCard(selected: Bool = false, padding: CGFloat = 12) -> some View {
		modifier(FRCardModifier(selected: selected, padding: padding))
	}
	
	/// Makes a list row transparent so the card inside shows on the grouped background.
	func frListRow() -> some View {
		self
			.listRowSeparator(.hidden)
			.listRowBackground(Color.clear)
			.listRowInsets(FRTheme.rowInsets)
	}
}

// MARK: - Settings icon tile
struct FRIconTile: View {
	let systemImage: String
	let color: Color
	
	var body: some View {
		Image(systemName: systemImage)
			.font(.system(size: 15, weight: .semibold))
			.foregroundStyle(.white)
			.frame(width: 30, height: 30)
			.background(
				RoundedRectangle(cornerRadius: 8, style: .continuous)
					.fill(
						LinearGradient(
							colors: [color, color.opacity(0.7)],
							startPoint: .top,
							endPoint: .bottom
						)
					)
			)
	}
}

struct FRSettingsLabel: View {
	let title: String
	let systemImage: String
	let color: Color
	
	init(_ title: String, systemImage: String, color: Color) {
		self.title = title
		self.systemImage = systemImage
		self.color = color
	}
	
	var body: some View {
		Label {
			Text(title)
		} icon: {
			FRIconTile(systemImage: systemImage, color: color)
		}
	}
}
