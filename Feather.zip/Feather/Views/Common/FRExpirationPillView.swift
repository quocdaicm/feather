//
//  FRExpirationPillView.swift
//  Feather
//
//  Created by samara on 7.05.2025.
//

import SwiftUI

// MARK: - View
struct FRExpirationPillView: View {
	let title: String
	let revoked: Bool
	let expiration: Date.ExpirationInfo?
	
	var body: some View {
		let isAction = (expiration == nil) && !revoked
		
		let textLabel: String = revoked
			? .localized("Revoked")
			: (expiration?.formatted ?? title)
		
		let tint: Color = revoked
			? Color.red
			: (expiration?.color ?? Color.accentColor)
		
		Text(textLabel)
			.lineLimit(1)
			.font(.subheadline.weight(.semibold))
			.foregroundStyle(isAction ? Color.white : tint)
			.padding(.horizontal, 14)
			.padding(.vertical, 7)
			.background(isAction ? tint : tint.opacity(0.15))
			.clipShape(Capsule())
	}
}
